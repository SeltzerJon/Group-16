// App.js
import React, { useState, useEffect } from 'react';
import { NavigationContainer } from '@react-navigation/native';
import { createStackNavigator } from '@react-navigation/stack';
import MainScreen from './screens/MainScreen';
import RestaurantDetails from './screens/RestaurantDetails';
import LoadingScreen from './screens/LoadingScreen'; // Import your LoadingScreen component

const Stack = createStackNavigator();

const App = () => {
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    // Simulate a loading delay (replace with your actual loading logic)
    const timeout = setTimeout(() => {
      setLoading(false);
    }, 3000); // 3 seconds

    // Clear the timeout if the component unmounts
    return () => clearTimeout(timeout);
  }, []);

  // Show the loading screen until loading is complete
  if (loading) {
    return <LoadingScreen />;
  }

  return (
    <NavigationContainer>
      <Stack.Navigator>
        <Stack.Screen name="Main" component={MainScreen} />
        <Stack.Screen name="RestaurantDetails" component={RestaurantDetails} />
        {/* Add other screens here */}
      </Stack.Navigator>
    </NavigationContainer>
  );
};

export default App;
