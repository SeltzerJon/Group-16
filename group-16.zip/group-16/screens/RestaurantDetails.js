// RestaurantDetails.js
import React from 'react';
import { View, Text, Button, StyleSheet } from 'react-native';

const RestaurantDetails = ({ route }) => {
  const { restaurantName } = route.params;

  return (
    <View style={styles.container}>
      {/* Restaurant Name */}
      <Text style={styles.restaurantName}>{restaurantName}</Text>

      {/* Restaurant Description */}
      <Text style={styles.description}>
        Welcome to our restaurant! We offer delicious and diverse cuisine.
      </Text>

      {/* Restaurant Address */}
      <Text style={styles.address}>123 Main Street, Cityville, Country</Text>

      {/* Restaurant Phone Number */}
      <Text style={styles.phoneNumber}>Phone: 1-555-123-4567</Text>

      {/* Restaurant Star Rating (you might want to use a third-party library for this) */}
      {/* Add more details or components as needed */}

      {/* Buttons */}
      <Button title="Map" style={styles.button} />
      <Button title="Directions" style={styles.button} />
      <Button title="Share" style={styles.button} />
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    padding: 16,
  },
  restaurantName: {
    fontSize: 24,
    fontWeight: 'bold',
    marginBottom: 10,
  },
  description: {
    fontSize: 16,
    marginBottom: 10,
  },
  address: {
    fontSize: 16,
    marginBottom: 10,
  },
  phoneNumber: {
    fontSize: 16,
    marginBottom: 10,
  },
  button: {
    marginTop: 10,
  },
});

export default RestaurantDetails;
