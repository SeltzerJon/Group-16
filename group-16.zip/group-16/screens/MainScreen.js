// MainScreen.js
import React, { useEffect } from 'react';
import { View, Text, TouchableOpacity, FlatList, StyleSheet, Image } from 'react-native';
import { useNavigation } from '@react-navigation/native';

const MainScreen = () => {
  const navigation = useNavigation();

  // Sample data for the list
  const restaurants = [
    "Pai", "Kington Ramen", "McDonalds",
    "Ali Baba", "Burger King", "Wendys", "Tim Hortons",
    "ChaTime", "CoCo's", "Starbucks"
  ];

  useEffect(() => {
    // Any initialization logic you need can go here
  }, []);

  const handleRestaurantPress = (restaurant) => {
    // Navigate to details screen with the selected restaurant
    navigation.navigate('RestaurantDetails', { restaurantName: restaurant });
  };

  return (
    <View style={styles.container}>
      {/* Restaurant List */}
      <FlatList
        data={restaurants}
        keyExtractor={(item, index) => index.toString()}
        renderItem={({ item }) => (
          <TouchableOpacity
            style={styles.restaurantItem}
            onPress={() => handleRestaurantPress(item)}
          >
            <Text>{item}</Text>
          </TouchableOpacity>
        )}
      />

      {/* Button Container */}
      <View style={styles.buttonContainer}>
        <TouchableOpacity style={styles.button}>
          <Text>Add</Text>
        </TouchableOpacity>
        <TouchableOpacity style={styles.button}>
          <Text>Delete</Text>
        </TouchableOpacity>
      </View>

      {/* Toolbar */}
      <View style={styles.toolbar}>
        {/* Your toolbar content goes here */}
      </View>

      {/* Logo Image */}
      <Image
        style={styles.logo}
        source={require('../assets/logo.png')}
        resizeMode="contain"
      />
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    padding: 16,
    justifyContent: 'center',
    alignItems: 'center',
  },
  restaurantItem: {
    padding: 16,
    borderBottomWidth: 1,
    borderBottomColor: '#ccc',
  },
  buttonContainer: {
    flexDirection: 'row',
    width: 230,
    height: 91,
    padding: 16,
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  button: {
    flex: 1,
    backgroundColor: '#007bff', // Adjust the color as needed
    padding: 16,
    marginHorizontal: 8,
    borderRadius: 8,
    justifyContent: 'center',
    alignItems: 'center',
  },
  toolbar: {
    width: '100%',
    height: 'auto',
    backgroundColor: '#007bff', // Replace with your primary color
  },
  logo: {
    width: '100%',
    height: 'auto',
    alignSelf: 'center',
  },
});

export default MainScreen;
