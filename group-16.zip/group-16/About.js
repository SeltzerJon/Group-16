// About.js
import React from 'react';
import { View, Text, FlatList, StyleSheet } from 'react-native';
import { useNavigation } from '@react-navigation/native';
import { Toolbar } from 'react-native-material-ui';

const About = () => {
  const navigation = useNavigation();

  // Array of Students
  const studentInfo = [
    "Student Name: Jon\nStudent Id: 101124255",
    "Student Name: Adina\nStudent Id: 101391769",
    "Student Name: Khadija\nStudent Id: 101240746",
    "Student Name: Sabirin\nStudent Id: 101363605",
  ];

  return (
    <View style={styles.container}>
      {/* Toolbar */}
      <Toolbar
        centerElement="About"
        leftElement="arrow-back"
        onLeftElementPress={() => navigation.goBack()}
      />

      {/* Student List */}
      <FlatList
        data={studentInfo}
        keyExtractor={(item, index) => index.toString()}
        renderItem={({ item }) => (
          <View style={styles.itemContainer}>
            <Text style={styles.itemText}>{item}</Text>
          </View>
        )}
      />
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  itemContainer: {
    padding: 16,
    borderBottomWidth: 1,
    borderBottomColor: '#ccc',
  },
  itemText: {
    fontSize: 16,
  },
});

export default About;
